package com.bit.studentscore;

import java.util.*;
public class Method {
	
	
	HashMap<Integer, Student> stu;
	
	void create(Student st){
		
	}
	
}
